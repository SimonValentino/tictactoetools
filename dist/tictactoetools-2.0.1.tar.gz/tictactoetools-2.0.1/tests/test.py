from tictactoetools.tictactoetools import play, get_player_stats, get_match_stats


print(get_match_stats())

