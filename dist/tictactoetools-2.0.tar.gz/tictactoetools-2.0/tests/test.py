from tictactoetools.tictactoetools import play


play()
