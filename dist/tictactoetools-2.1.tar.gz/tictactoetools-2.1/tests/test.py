from tictactoetools.tictactoetools import play, get_player_stats


play()

